#ifndef UNICODE
	#undef _UNICODE
#else
	#ifndef _UNICODE
		#define _UNICODE
	#endif
#endif

#include <windows.h>
#include <cstdlib>

#include <iostream>

using namespace std;

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR szCmdLine, int iCmdShow) {
	CHOOSEFONT cf;
	LOGFONT lf;
	BOOL b;
	HDC hDC;
	HFONT hFont;
	HGDIOBJ hOldFont;
	DWORD dwPairs;
	KERNINGPAIR *pKerns;
	
	memset(&cf,0,sizeof(CHOOSEFONT));
	cf.lStructSize=sizeof(CHOOSEFONT);
	cf.lpLogFont=&lf;
	
	b=ChooseFont(&cf);
	
	lf.lfHeight=1000;
	
	if(!b) {
		MessageBox(NULL,TEXT("Font choosing failed"),NULL,MB_OK|MB_ICONINFORMATION);
		return -1;
	}
		
	hFont=CreateFontIndirect(cf.lpLogFont);
	if(!hFont) {
		MessageBox(NULL,TEXT("Can't create font object"),NULL,MB_OK|MB_ICONERROR);
		return -1;
	}
	
	hDC=GetDC(NULL);
	if(!hDC) {
		MessageBox(NULL,TEXT("Can't get device context"),NULL,MB_OK|MB_ICONERROR);
		return -1;
	}
	
	hOldFont=SelectObject(hDC,hFont);
	if(!hOldFont||hOldFont==HGDI_ERROR) {
		MessageBox(NULL,TEXT("Can't select font for device context"),NULL,MB_OK|MB_ICONERROR);
		return -1;
	}
	
	dwPairs=GetKerningPairs(hDC,0,NULL);
	
	cout<<dwPairs<<" kerning pairs detected"<<endl;
	
	pKerns=new KERNINGPAIR[dwPairs];
	
	dwPairs=GetKerningPairs(hDC,dwPairs,pKerns);
	
	cout<<dwPairs<<" kerning pairs received"<<endl;
	
	for(int i=0;i<dwPairs;i++) {
		cout<<hex<<pKerns[i].wFirst<<" "<<pKerns[i].wSecond<<dec<<" "<<pKerns[i].iKernAmount<<endl;
	}
	
	return 0;
}
